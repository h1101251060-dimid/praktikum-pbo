<?php
class Mobil {
    private $merek;
    private $warna;
    private $kecepatan;
    private $sedangJalan;

    public function __construct($merek, $warna, $kecepatan) {
        $this->merek = $merek;
        $this->warna = $warna;
        $this->kecepatan = $kecepatan;
        $this->sedangJalan = false;
    }

    public function getInfo() {
        if ($this->sedangJalan) {
            return "Mobil: {$this->merek}, Warna: {$this->warna}, Status: Berjalan, Kecepatan: {$this->kecepatan} km/jam";
        }
        return "Mobil: {$this->merek}, Warna: {$this->warna}, Status: Berhenti";
    }

    public function jalankan() {
        if ($this->sedangJalan) {
            return "{$this->merek} sudah dalam keadaan berjalan";
        }
        $this->sedangJalan = true;
        return "{$this->merek} mulai berjalan dengan kecepatan {$this->kecepatan} km/jam...";
    }

    public function berhenti() {
        if (!$this->sedangJalan) {
            return "{$this->merek} sudah dalam keadaan berhenti";
        }
        $this->sedangJalan = false;
        return "{$this->merek} berhenti";
    }
}

// Membuat 3 objek berbeda
$mobil1 = new Mobil("Toyota Avanza", "Hitam", 120);
$mobil2 = new Mobil("Honda Civic", "Putih", 180);
$mobil3 = new Mobil("Suzuki Ertiga", "Merah", 100);

$daftarMobil = [$mobil1, $mobil2, $mobil3];

foreach ($daftarMobil as $mobil) {
    echo $mobil->getInfo() . "<br>";
    echo $mobil->jalankan() . "<br>";
    echo $mobil->getInfo() . "<br>";
    echo $mobil->berhenti() . "<br>";
    echo $mobil->getInfo() . "<br>";
    echo "-----------------------------<br>";
}